# cltl-vad
Voice activity detection service.

Split voice activities are necessary for STT, etc.
